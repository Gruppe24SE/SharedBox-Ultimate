package com.example.demo;

import java.util.jar.Attributes;

public class Benutzer {
    public String Nachname;
    public String Vorname;
    private String Passwort;
    public String RegDate;
    public String Abteilung;
    public String email;

    public void setPasswort(String passwort) {Passwort = passwort;}
    public void setRegDate(String regDate) {
        RegDate = regDate;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setAbteilung(String abteilung) {
        Abteilung = abteilung;
    }
    public void setVorname(String vorname) {
        Vorname = vorname;
    }
    public void setNachname(String nachname) {
        Nachname = nachname;
    }

    public Benutzer(String Vorname, String Nachname, String Passwort, String Abteilung, String email ){
        this.Vorname= Vorname;
        this.Nachname= Nachname;
        this.Passwort= Passwort;
        this.Abteilung= Abteilung;
        this.email= email;
    }
}
