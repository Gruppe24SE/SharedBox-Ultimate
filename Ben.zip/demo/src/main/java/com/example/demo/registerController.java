package com.example.demo;

import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class registerController {
    public registerController() {
        /*
         this.cbRegUnternehmen = new ComboBox<>();
         this.cbRegUnternehmen.getItems().addAll("Pimmelwimmel", "sdfasd", "sdgfasdf");         geht nicht
        */
    }

    private Stage stage;
    private Scene scene;
    private Parent root;

    public void switchToScene2(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private Button btnReg;
    @FXML
    public ComboBox<String> cbRegUnternehmen;
    @FXML
    private TextField tfRegNachname;
    @FXML
    private TextField tfregPasswort;
    @FXML
    private TextField tfregVorname;
    @FXML
    private TextField tfregemail;

    @FXML
    public void btnReg(ActionEvent event) {
        try {
            Benutzer user = new Benutzer(tfregVorname.getText(), tfRegNachname.getText(), tfregPasswort.getText(), cbRegUnternehmen.getValue().toString(), tfregemail.getText());
        } catch (Exception e) {
            System.out.println("Der Fehler \"" + e + "\" ist aufgetreten!");
        }
    }
}

//fehler noch, da Combobox kein Inhalt hat noch und Admin erbt noch nicht von Benutzer