package com.example.demo;

public class Unternehmen {
    public Unternehmen(String name) {
        Name = name;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    private String Name;
}
